package com.klu.springmvc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ms2")
public class MS2Controller {
	@GetMapping("/mul")
	public String mul(@RequestParam("a") int a,
			@RequestParam("b") int b) {
		
		int result=a*b;
		return "MS2.2 multiplication"+result;
	}

}
